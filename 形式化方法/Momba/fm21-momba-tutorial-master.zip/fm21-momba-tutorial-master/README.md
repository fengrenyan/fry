# FM'21: Momba Tutorial

This project is part of a Momba tutorial co-located with FM21.

The tutorial is [available online](https://fm21.momba.dev).


# Structure

- `fmracer`: Contains a skeleton Python package for the tutorial.
- `tracks`: Contains *track files* for the tutorial.
- `solutions`: Contains solutions for the exercises of the tutorial.
