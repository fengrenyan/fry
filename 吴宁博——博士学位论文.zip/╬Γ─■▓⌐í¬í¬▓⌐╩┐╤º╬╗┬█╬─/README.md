# doctoral-thesis
丁红发,理性隐私保护模型及应用.贵阳:贵州大学，2019.
